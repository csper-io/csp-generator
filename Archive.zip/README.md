# Csper-Builder

Csper-Builder is a chrome extension that helps build a Content-Security-Policy for any website. 

It can be downloaded here:
https://chrome.google.com/webstore/detail/csper-builder/ahlnecfloencbkpfnpljbojmjkfgnmdc

https://csper.io


