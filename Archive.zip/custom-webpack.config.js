module.exports = {
    entry: { background: 'src/background.ts' },
}
