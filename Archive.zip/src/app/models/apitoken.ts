
export interface APIToken {
    id: string
    ts: string

    projectID: string
    role: string

    comment: string
    token: string

    isEnabled: boolean
}