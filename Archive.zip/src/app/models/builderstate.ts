
export interface BuilderState {
    id: string
    ts: string

    projectID: string
    token: string

    domain: string
    isEnabled: boolean
    policy: string
}