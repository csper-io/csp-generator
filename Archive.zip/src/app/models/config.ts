export interface Config {
    env: string
    hostname: string
}