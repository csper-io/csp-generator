export interface Endpoint {
    id: string
    projectID: string

    isActive: boolean

    name: string
    ts: string
}
