export interface Membership {
    ts : string 

    inviter : string 
    email : string 
    role : string  
}