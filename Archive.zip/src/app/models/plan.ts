export interface Plan {
    name: string
    tier : string 

    stripePlanID : string
    reportCount: number
    price : number 
}