export interface Timeseries {
    start : string 
    end : string 

    dataset : any
    labels : string[]
}