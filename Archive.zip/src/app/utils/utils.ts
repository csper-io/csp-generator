
export function isNullID(id: string): boolean {
    return id == "000000000000000000000000"
}
