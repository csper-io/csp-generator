export const environment = {
  production: true,
  origin: "https://csper.io",
  wsOrigin: "csper.io"
};